/**
 * Created by Administrator on 2018/5/4/004.
 */
export default {
  modifyUserInfoAction ({commit}, obj) {
    commit('modifyUserInfo', obj)
  }
}

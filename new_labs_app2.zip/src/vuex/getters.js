/**
 * Created by Administrator on 2018/5/6/006.
 */
export default {
  userInfo (state) {
    return state.userInfo
  }
}

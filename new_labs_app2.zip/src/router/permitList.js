/**
 * Created by Administrator on 2018/5/12/012.
 */
export default {
  loginRouter: {
    '/myCollections': true,
    '/personalInfo': true,
    '/nickName': true,
    '/personalIntro': true,
    '/adviceFeedback': true,
    '/passwordModify': true,
    '/emailLink': true,
    '/phoneLink': true,
    '/accountSecurity': true
  }
}
